with open("frame0.txt","r")as f:
    print(len(f.read()))