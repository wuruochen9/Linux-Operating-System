#ifndef TESTS_H
#define TESTS_H

// test launcher
void launch_tests();
int get_rtc_test();
#endif /* TESTS_H */
